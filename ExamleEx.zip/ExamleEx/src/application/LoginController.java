package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class LoginController {

    @FXML
    private TextField loginTextField;

    @FXML
    private Button opentButton;

    @FXML
    private TextField passwordTextField;

    @FXML
    void opentButtonClick(ActionEvent event) {
    	if(passwordTextField.getText().equals("555")) {
    	
    	System.out.println("Ok");
    	try {
			BorderPane root = (BorderPane)FXMLLoader.load(getClass().getResource("Sample.fxml"));
			Scene scene = new Scene(root,400,400);
			Stage stage=(Stage)opentButton.getScene().getWindow();
            stage.setScene(scene);  		
    	} catch(Exception e) {
			e.printStackTrace();
		}}
    	else
    	{
    		Alert aler = new Alert(AlertType.INFORMATION);
    		aler.setContentText("Ошибка пароль");
    		aler.showAndWait();
    	}
    }

}
package application;

import java.time.LocalDate;

public class Request {
	
	int id;
	LocalDate startDate;
	String computerTechType;
	String problemDesryption;
	@Override
	public String toString() {
		return "Request [id=" + id + ", startDate=" + startDate + ", computerTechType=" + computerTechType
				+ ", problemDesryption=" + problemDesryption + "]";
	}
	public Request() {
		super();
	}
	public Request(int id, LocalDate startDate, String computerTechType, String problemDesryption) {
		super();
		this.id = id;
		this.startDate = startDate;
		this.computerTechType = computerTechType;
		this.problemDesryption = problemDesryption;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public LocalDate getStartDate() {
		return startDate;
	}
	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}
	public String getComputerTechType() {
		return computerTechType;
	}
	public void setComputerTechType(String computerTechType) {
		this.computerTechType = computerTechType;
	}
	public String getProblemDesryption() {
		return problemDesryption;
	}
	public void setProblemDesryption(String problemDesryption) {
		this.problemDesryption = problemDesryption;
	}


}

package application;

import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

public class SampleController implements Initializable  {

    @FXML
    private Button buttonAdd;

    @FXML
    private TextField modelTextField;

    @FXML
    private ListView<Request> requestLisView;

    @FXML
    private DatePicker startTimePicker;

    @FXML
    private TextField typeTextField;

    @FXML
    void buttonAddClick(ActionEvent event) {
    	requests.add(new Request(2,startTimePicker.getValue(),typeTextField.getText(),modelTextField.getText()));

    }
ObservableList<Request> requests=FXCollections.observableArrayList(); 
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
	requests.add(new Request(1,LocalDate.of(1990, 1, 1),"dd","dd"));
	requestLisView.setItems(requests);
		
	}

}
